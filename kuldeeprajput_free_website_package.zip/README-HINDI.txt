कुलदीप राजपूत की वेबसाइट — प्रकाशित करने के लिए

फाइलें:
- index.html : वेबसाइट का मुख्य पेज

मुफ्त होस्टिंग का सुझाया तरीका: GitHub Pages
1. github.com पर अपना अकाउंट बनाएं/लॉगिन करें।
2. नया Public repository बनाएं। नाम रखें: kuldeeprajput-site
3. इस पैकेज की index.html फाइल repository में Upload files से अपलोड करें।
4. Settings > Pages खोलें।
5. Build and deployment में Deploy from a branch चुनें।
6. Branch: main और folder: /(root) चुनकर Save करें।
7. GitHub कुछ समय बाद मुफ्त वेबसाइट लिंक देगा: https://USERNAME.github.io/kuldeeprajput-site/

महत्वपूर्ण:
- kuldeeprajput.in एक अलग कस्टम डोमेन है। .in डोमेन सामान्यतः पंजीकरण शुल्क देकर खरीदना पड़ता है; मुफ्त GitHub Pages होस्टिंग से डोमेन मुफ्त नहीं मिलता।
- डोमेन खरीदने के बाद GitHub Pages की Custom domain सेटिंग और DNS रिकॉर्ड कॉन्फ़िगर करके जोड़ा जा सकता है।
- वेबसाइट पर अपनी वास्तविक फोटो, यूनियन का लोगो, आधिकारिक ईमेल और सार्वजनिक संपर्क नंबर जोड़ने से पहले उनकी पुष्टि करें।
- फिलहाल वेबसाइट का फोटो स्थान केवल placeholder है।
